# Determina si los pares de segmentos de cada renglon intersectan usando Shapely.
# Alvaro Gonzalez Martinez A01646343 | Valeria Fernanda Hernandez Avilan A01640968
# Fecha: 12 de noviembre de 2026.

from shapely.geometry import LineString, Point


# Determina si dos segmentos comparten al menos un punto usando Shapely.
# Parametros: coordenadas contiene ocho numeros: x e y de cuatro puntos;
# los primeros dos puntos forman un segmento y los otros dos forman el segundo.
# Si los extremos de un segmento son iguales, se representa como un punto.
# Retorno: True si los segmentos intersectan; False en caso contrario.
# Complejidad: O(1) en tiempo y espacio, porque solo se comparan dos segmentos
# de dos extremos cada uno, considerando operaciones numericas de costo constante.
def intersectan(coordenadas):
	if coordenadas[0] == coordenadas[2] and coordenadas[1] == coordenadas[3]:
		segmento1 = Point(coordenadas[0], coordenadas[1])
	else:
		segmento1 = LineString([
			(coordenadas[0], coordenadas[1]),
			(coordenadas[2], coordenadas[3])
		])

	if coordenadas[4] == coordenadas[6] and coordenadas[5] == coordenadas[7]:
		segmento2 = Point(coordenadas[4], coordenadas[5])
	else:
		segmento2 = LineString([
			(coordenadas[4], coordenadas[5]),
			(coordenadas[6], coordenadas[7])
		])

	return segmento1.intersects(segmento2)


# Lee grupos de cuatro puntos e imprime la lista de resultados de interseccion.
# Parametros: no recibe parametros; lee ocho numeros separados por comas
# en cada renglon de la entrada estandar. Una linea vacia termina la captura.
# Retorno: no regresa un valor explicito; muestra la lista en la salida estandar.
# Complejidad: O(n) en tiempo y O(n) en espacio para guardar los n/4 resultados,
# donde n es el total de puntos y cada coordenada tiene longitud acotada.
def main():
	resultados = []
	linea = input()

	while linea != "":
		numeros = linea.split(",")
		coordenadas = []

		for numero in numeros:
			coordenadas.append(float(numero))

		resultado = intersectan(coordenadas)
		resultados.append(resultado)
		linea = input()

	print(resultados)


main()
